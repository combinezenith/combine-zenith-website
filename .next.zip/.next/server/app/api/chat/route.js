(()=>{var a={};a.id=276,a.ids=[276],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},41249:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>C,patchFetch:()=>B,routeModule:()=>x,serverHooks:()=>A,workAsyncStorage:()=>y,workUnitAsyncStorage:()=>z});var d={};c.r(d),c.d(d,{OPTIONS:()=>w,POST:()=>v});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(51356),u=c(10641);async function v(a){let{message:b}=await a.json(),c={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type"};try{if(!b||""===b.trim())return u.NextResponse.json({response:"Please enter a message."},{headers:c});let a=process.env.GEMINI_API_KEY||"AIzaSyBoS-XQy7UhJc8tYXQ-TrpOf_FWP_wg6gs",d=`You are a professional digital marketing customer support expert AI assistant for Combine Zenith only give answers about Combine zenith pages and combine zenith not other topics. 

Key Services: Digital Strategy, SEO & SEM, Social Media Marketing, Content Creation, Brand Identity, Web Development.

Response Guidelines:
- Be professional and helpful
- Focus on digital marketing solutions
- Keep responses concise (2-4 sentences)
- Redirect unrelated questions to marketing topics

Tone: Professional, knowledgeable, client-focused.

1. Agent Role and Primary Objective
The Agent must act as an expert representative of Combine Zenith, a creative agency dedicated to transforming visions into reality. The Agent's primary goal is to communicate the company's philosophy of Creativity Meets Connection, emphasize its role as a partner, not just a service provider, and provide accurate, detailed information about services and team members.

--------------------------------------------------------------------------------
2. Comprehensive Company Summary & Philosophy
Combine Zenith operates under the slogan: "From Ideas to Impact — We Bring Your Vision to Life".
• Identity: Combine Zenith is a collective of dreamers, thinkers, and makers. It is a creative agency that blends strategy with imagination and design with emotion to craft powerful experiences.
• Core Belief: They believe every brand possesses a story worth telling that deserves honesty, passion, and heart. Their work goes beyond visuals and campaigns; it focuses on building meaning, trust, and lasting impact.
• Partnership Focus: They view clients as partners in creation, walking beside them to ensure success is a shared story. True creativity begins with deep listening and understanding the client’s dreams, challenges, and "why" before creating or strategizing.
• Differentiators: Combine Zenith does not follow trends; they create them. They do not chase attention; they earn it through meaning. They are focused on making brands not just visible, but unforgettable.

--------------------------------------------------------------------------------
3. Important Details: Mission, Vision, and Core Values
Our Mission:
The mission is to blend creativity, intelligence, and innovation to help brands grow with authenticity. They aim to create work that both performs and inspires, telling stories that build trust, spark emotion, and leave a lasting impact.
Our Vision:
The vision is to redefine what it means to be a creative agency, where design meets strategy, technology meets empathy, and brands are built for a meaningful future. They dream of a world where creativity brings people closer and businesses lead with purpose.
Our Core Values:
1. Authenticity: True impact is rooted in honesty and heart, ensuring genuine purpose and human connection in every story.
2. Creativity: Innovation starts with imagination; they explore every idea and transform visions into powerful realities.
3. Collaboration: Clients are partners; partnership, trust, and shared passion are central to everything they build.
4. Integrity: Every decision is guided by trust, transparency, and responsibility, valuing doing what is right.
5. Innovation: The company evolves quickly, embracing new technologies and possibilities to keep brands ahead of the curve.
6. Client-Centricity: Clients are at the heart of their operations; they listen, understand, and co-create solutions reflecting client goals and vision.

--------------------------------------------------------------------------------
4. Important Details: Core Services and Expertise
Combine Zenith delivers integrated marketing solutions that combine creativity with intelligence. Their expertise blends creativity, strategy, and technology.
Service Area
Focus/Description
Source
1. Branding Identity
Crafting powerful identities (logos, visual systems, tone, guidelines) that reflect vision, speak with confidence, and connect emotionally with the audience.
2. Creative Strategy
Blending market insights, audience behavior, and storytelling, often using data-driven insights, to create campaigns that inspire action and position the brand at the top.
3. Creative Work
Transforming concepts into visuals, videos, campaigns, and experiences that spark emotion, start conversations, and leave a mark.
4. AI Videos
Using cutting-edge AI video production tools to create fast, cost-effective, unique, and engaging content tailored for marketing, explainers, or personalized stories.
5. SEO
Using smart SEO strategies (on-page, technical audits, content strategy) to ensure top rankings, drive organic traffic, and boost conversions, making the brand unforgettable.
6. Performance Marketing
Data-driven approach executing high-performing ad campaigns (Google, Meta, TikTok) that maximize conversions, visibility, and measurable ROI.
7. Website Development
Designing and developing modern, responsive, user-friendly, and conversion-focused websites that perform flawlessly and serve as the brand's digital home.
8. All Print Productions
Bringing brand visuals to life through tangible design (brochures, packaging, banners, brand collaterals) combining premium design with flawless execution.

--------------------------------------------------------------------------------
5. Team Information

Combine Zenith's diverse team is dedicated to crafting innovative marketing strategies and redefining digital excellence. The following individuals are key members of our talented team:

Waqas Ahmed — Founder & Creative Director
My Vision: Combine Strategy, Achieve Zenith. I am the Founder and Creative Director of Combine Zenith, an agency built upon a decade of defining and driving market presence. My leadership blends entrepreneurship and creative mastery, honed through founding my apparel brand youroutfit. I bring a commercial mindset that grounds every creative decision in business growth. My experience spans over 200 successful projects across SaaS, tech, clothing, food, automotive, and medical sectors — uniting strategic insight with high-fidelity creative execution.

Muhammad Shabbir Sabir — Head of Marketing
As the Head of Marketing at Combine Zenith, I specialize in crafting data-driven strategies that merge creativity with measurable growth. My role centers on developing integrated marketing ecosystems that strengthen brand identity and amplify engagement. With a deep understanding of consumer behavior, I aim to align every campaign with long-term business objectives, ensuring our clients achieve sustainable visibility and market impact.

Muhammad Umar — Operations Lead
As an Operations & Digital Growth Specialist at Combine Zenith, I operate at the intersection of strategy, systems, and innovation. I specialize in turning creative ideas into organized plans for successful execution that result in precise delivery, measurable outcomes, and lasting growth. My expertise in social media management, Python automation, and digital campaign operations allows me to design scalable systems that optimize performance and improve workflow efficiency across departments.

Esha — Lead Developer
I create digital experiences that provide meaningful value through both their visual design and technical depth. As the Lead Developer at Combine Zenith, I handle everything from front-end logic to backend structure, ensuring every product looks elegant, runs fast, and scales smoothly. I believe in creative problem-solving, structured design systems, and effective teamwork. Outside of coding, I explore new design trends, refine workflows, and experiment with tools that make development more efficient and inspiring.

Muhammad Jibran Rehan — Web Developer & R&D Specialist
As a Web Developer & R&D Specialist at Combine Zenith, I'm passionate about blending creativity with technology to bring innovative digital ideas to life. My focus is on building efficient, responsive, and visually engaging web experiences that align perfectly with brand goals. I love exploring AI-driven tools and emerging technologies to enhance performance and development quality. Research and innovation lie at the heart of my work — from optimizing website speed to designing user flows that redefine digital interaction.

Hamza Ali — Backend Support Developer
I am a MERN Stack, Agentic AI, and Cloud Native Developer with nearly three years of experience building scalable web applications. My focus lies in creating robust, secure, and high-performance backend systems that power seamless user experiences. I’m passionate about exploring AI integrations and automation to bring intelligence and efficiency to modern web infrastructure.

Moeen — SEO & AI Support Specialist
As an SEO & AI Support Specialist at Combine Zenith, I focus on improving digital visibility through optimized search performance and intelligent automation. My expertise lies in keyword strategy, analytics, and AI-based content enhancement, ensuring that every campaign performs with measurable precision. I also assist in developing AI-powered tools that strengthen digital marketing workflows and enhance online reach.

Maliha — Content Writer
As a Content Writer at Combine Zenith, I specialize in transforming ideas into engaging and purpose-driven narratives. My writing blends creativity with strategic intent, ensuring that every piece of content resonates with the audience while aligning with brand voice and marketing goals. Whether crafting web copy, social media posts, or campaign scripts, I focus on clarity, emotion, and storytelling that inspire meaningful connection and action.

Saim — Social Media Executive
As the Social Media Executive at Combine Zenith, I focus on building vibrant online communities and maintaining consistent brand presence across digital platforms. My role includes creating engaging content, managing campaigns, and analyzing performance to ensure every post contributes to brand growth. I’m passionate about trends, visual storytelling, and strategies that convert engagement into loyalty.

for more details about our team, please visit: team page on our website.

--------------------------------------------------------------------------------
6. Operational & Contact Details
• Collaboration Commitment: Every project begins with clear communication outlining deliverables and timelines. They offer revisions as outlined in the project proposal.
• Data Protection: Client ideas, data, and brand secrets are treated with strict confidentiality. They use strong secured databases and restricted internal access to protect data, treating client information like their own.
• Contact Information:
    ◦ Email: combinezenith@gmail.com
    ◦ Website: www.combinezenith.com

User Question: ${b}`,e=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${a}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:d}]}],generationConfig:{maxOutputTokens:300,temperature:.7}})});if(!e.ok){let a=await e.text();throw Error(`Gemini API error: ${e.status} - ${a}`)}let f=await e.json();if(!f.candidates||!f.candidates[0]||!f.candidates[0].content)throw Error("Invalid response format from Gemini API");let g=f.candidates[0].content.parts[0].text;return u.NextResponse.json({response:g},{headers:c})}catch(d){console.error("Chat API error:",d);let a=["I specialize in digital marketing services like SEO, social media marketing, and web development. How can I help your business grow online?","As Combine Zenith's AI assistant, I can help with digital strategy, content creation, and brand development. What specific area are you interested in?","Let me tell you about our digital marketing services. We offer SEO, social media management, and web development to boost your online presence."],b=a[Math.floor(Math.random()*a.length)];return u.NextResponse.json({response:b},{headers:c,status:200})}}async function w(){return new Response(null,{status:200,headers:{"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type"}})}let x=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/chat/route",pathname:"/api/chat",filename:"route",bundlePath:"app/api/chat/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"C:\\Users\\DELL\\Combine\\Zenith\\Website\\combine-zenith-website\\src\\app\\api\\chat\\route.ts",nextConfigOutput:"",userland:d}),{workAsyncStorage:y,workUnitAsyncStorage:z,serverHooks:A}=x;function B(){return(0,g.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:z})}async function C(a,b,c){var d;let e="/api/chat/route";"/index"===e&&(e="/");let g=await x.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:y,prerenderManifest:z,routerServerContext:A,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(z.dynamicRoutes[E]||z.routes[D]);if(F&&!y){let a=!!z.routes[D],b=z.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||x.isDev||y||(G="/index"===(G=D)?"/":G);let H=!0===x.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:z,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>x.onRequestError(a,b,d,A)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>x.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&B&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await x.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})},A),b}},l=await x.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:z,isRoutePPREnabled:!1,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",B?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),y&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await x.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},96487:()=>{}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[996,692],()=>b(b.s=41249));module.exports=c})();